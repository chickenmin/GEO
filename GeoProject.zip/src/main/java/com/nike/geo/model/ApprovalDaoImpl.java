package com.nike.geo.model;

import org.springframework.stereotype.Repository;

@Repository
public class ApprovalDaoImpl {

}
