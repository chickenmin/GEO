package com.nike.geo.model;

public interface IApprovalDao {

}
