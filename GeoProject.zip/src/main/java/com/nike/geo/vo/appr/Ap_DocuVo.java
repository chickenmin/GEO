package com.nike.geo.vo.appr;

//롬복 사용
public class Ap_DocuVo {

	//멤버필드 : 컬럼 복사해온 후, 소문자로 변경해 사용
	//EX) APD_NO => apd_no
}
