package com.nike.geo.ctrl;

import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

//ajax 사용 컨틀로러
@Slf4j
@RestController
public class ApprovalRestController {

}
