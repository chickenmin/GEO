package com.nike.geo.ctrl;

import org.springframework.stereotype.Controller;

import lombok.extern.slf4j.Slf4j;

//일반 컨트롤러
@Slf4j
@Controller
public class ApprovalController {
	
	

}
